export * from './vocab';
