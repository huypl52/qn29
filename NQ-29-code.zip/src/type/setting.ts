export interface ISetting {
  image_min_size: number;
  translate_timeout: number;
  image_max_size: number;
  document_max_length: number;
  image_queue_limit: number;
}
