export interface IOrg {
  id: string;
  name: string;
  parentid: string;
  grade: number;
}
