import { TabWithContent } from './TabWithContent';

export { TabWithContent };
