import StructureTextarea from './StructureTextarea';
import BaseTextarea from './BaseTextarea';

export { BaseTextarea, StructureTextarea };
