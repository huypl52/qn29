interface ICardRef {
  // ref?: React.RefObject<HTMLDivElement>;
}

export { type ICardRef };
