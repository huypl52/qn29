export type AuthUser = {
  token: string;
  refreshToken: string;
  createdAt: Date;
  role: number;
};
